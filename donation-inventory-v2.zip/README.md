# Donation Inventory Management System

A web application for tracking donated items with search, editing, and automated email notifications. Built with React, Supabase, and a warm, professional UI.

## Features

- **Add & Edit Items** — Capture donor name, email, address, phone, item details, storage location, and photos
- **Inventory Browser** — View all items with search, sort, expand for details, edit, and delete
- **Dashboard Stats** — At-a-glance totals, monthly intake, and pending notification counts
- **Image Upload** — Upload and preview item photos (up to 10 MB)
- **Phone Formatting** — Auto-formats phone numbers as you type
- **Automated Emails** — 30-day donor notifications via Supabase Edge Functions + Resend
- **Responsive** — Works on desktop, tablet, and mobile

## Tech Stack

- **Frontend**: React 18 + Vite
- **Backend**: Supabase (PostgreSQL + Storage + Edge Functions)
- **Email**: Resend API
- **Styling**: Pure CSS with custom design system

## Project Structure

```
donation-inventory/
├── src/
│   ├── App.jsx            # Main React component (form + inventory list)
│   ├── App.css            # All styles
│   ├── main.jsx           # React entry point
│   ├── index.css          # Root styles
│   └── supabaseClient.js  # Supabase config with error handling
├── supabase/
│   ├── schema.sql         # Database schema (run in Supabase SQL Editor)
│   └── functions/
│       └── email-notifications/
│           └── index.ts   # Edge function for 30-day emails
├── index.html
├── package.json
├── vite.config.js
└── .env.example           # Copy to .env and fill in credentials
```

## Quick Start

### 1. Supabase Setup

1. Create a project at [supabase.com](https://supabase.com)
2. Go to **SQL Editor**, paste the contents of `supabase/schema.sql`, and run it
3. Go to **Project Settings → API** and copy your Project URL and anon key

### 2. Local Development

```bash
npm install
cp .env.example .env
# Edit .env with your Supabase URL and anon key
npm run dev
```

Open http://localhost:5173

### 3. Deploy

Push to GitHub and connect to **Vercel**, **Netlify**, or **Cloudflare Pages**. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` as environment variables.

### 4. Email Notifications (Optional)

1. Sign up at [resend.com](https://resend.com) and get an API key
2. Install Supabase CLI and deploy the edge function:

```bash
npm install -g supabase
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase secrets set RESEND_API_KEY=your_key
supabase secrets set EMAIL_FROM=noreply@yourdomain.com
supabase secrets set ORG_NAME="Your Organization"
supabase functions deploy email-notifications
```

3. Create a daily cron job in Supabase to trigger the function at 9 AM.

## Security Notes

The current setup allows public access for development. For production, add Supabase Auth and update RLS policies to require authentication.

## Changelog (v2.0)

- Added donor email field (required for notifications)
- Added full inventory list view with search and sort
- Added edit and delete capabilities with confirmation
- Added dashboard stats (total, monthly, pending notifications)
- Added phone number auto-formatting
- Added image size validation (10 MB max)
- Added graceful handling when Supabase is not configured
- Added DELETE RLS policy and storage delete policy
- Added `.env.example` file
- Fixed edge function to use `donor_email` field correctly
- Fixed edge function to find items 30+ days old (not just exactly 30)
- Fixed duplicate CSS resets
- Organized file structure into proper `src/` and `supabase/` directories
- Added database indexes for donor name and storage location
